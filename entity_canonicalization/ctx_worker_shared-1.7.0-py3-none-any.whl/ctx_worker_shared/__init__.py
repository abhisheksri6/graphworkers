"""ctx_worker_shared — shared library for ContextBuilder v1 Celery workers.

Packaged from the former ``workers/shared`` monorepo folder so each worker repo
can install it from a local wheel (no git / no index at deploy time). Public
modules used by workers: ``storage``, ``db_session``, ``contract_validator``,
``worker_base``.

(``adapter_base`` was removed in 1.1.0 — intra-worker adapters are retired;
shape conversions flow through explicit format_adapter nodes on the canvas.)
"""

__version__ = "1.7.0"  # keep in step with pyproject.toml — a stale value here is how
                       # "which build am I running?" became unanswerable (2026-08-08)
